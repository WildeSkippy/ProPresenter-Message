package com.kdb.propresentermessage;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webView);
        WebSettings websettings = web.getSettings();
        websettings.setJavaScriptEnabled(true);
        websettings.setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new Callback());
        web.loadUrl("http://livestream.local:1025/html/pages/messages");
        web.loadUrl("http://laptop-5kql98h8.local:1025/html/pages/messages");
        web.loadUrl("http://192.168.178.103:1025/html/pages/messages");
    }

    private class Callback extends WebViewClient implements com.kdb.propresentermessage.Callback {
        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            return false;
        }
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            Toast.makeText(MainActivity.this, "No connectivity available", Toast.LENGTH_SHORT).show();
        }

    }
}