package com.kdb.propresentermessage;

import android.webkit.WebView;

public interface Callback {
    boolean shouldOverrideKeyEvent(WebView view, KeyEvent event);
}
